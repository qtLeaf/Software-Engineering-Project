package it.univr.wordautoma_10;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Graph {

    private final List<GraphManager.Node> nodeList;

    private String dotContent;

    private GraphManager graphManager;

    String dotFile;
    String imgFile;

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    public Graph(String fileName) {
        graphManager = new GraphManager();
        nodeList = new ArrayList<>();

        dotContent = "digraph " + " {\n" + "\tnode[fontname=\"Open Sans\", shape=\"circle\"]\n" + "\t\"\"[shape=\"none\"]";
        this.dotFile= PATH + fileName + ".dot";
        this.imgFile= PATH + fileName + ".png";
        close();
    }

    public GraphManager getGraphManager() {
        return graphManager;
    }

    public void addNode(String nodeName) {
        if (findNode(nodeName) == null) {
            nodeList.add(new GraphManager.Node(nodeName));
            System.out.println("Added node: " + nodeName);
        }
    }

    public GraphManager.Node findNode(String nodeName) {
        String normalizedNodeName = nodeName.trim().toLowerCase();
        // System.out.println("Searching for node: " + normalizedNodeName);
        // System.out.println("Total nodes in list: " + nodeList.size());
        for (GraphManager.Node node : nodeList) {
            String normalizedNodeNameInList = node.getName().trim().toLowerCase();
            // System.out.println("Checking node: " + normalizedNodeNameInList);
            if (normalizedNodeNameInList.equals(normalizedNodeName)) {
                // System.out.println("Node found: " + normalizedNodeName);
                return node;
            }
        }
        // System.out.println("Node not found: " + normalizedNodeName);
        return null;
    }

    // Aggiungo un arco tra due nodi inseriti (posso aggiungere qui in una lista con gli archi)
    public void addArrow(String node1, String value, String node2) {
        //rimovere ultima riga, se esiste la non la aggiungo
        if(!graphManager.nodeHasValue(node1, value)) {
            setDotContent("\t" + node1 + "->" + node2 + "[label=\"" + value + "\"]\n");
            graphManager.setArrow(node1, value, node2);
        }
    }

    public void setNodeInit(String node){
        if(!graphManager.hasInit()){
            setDotContent("\t\"\" -> " + node + "\n");
            graphManager.setInit(node);
        }
    }

    // Aggiunge graficamente un cerchio ad un nodo per renderlo finale
    public void setNodeFinal(String node){
        setDotContent("\t" + node + "[shape=\"doublecircle\"]\n");
        graphManager.setFinal(node);
    }

    //aggiunge una stringa al dotContent
    private void setDotContent(String existCheck){
        if(!dotContent.contains(existCheck)){
            dotContent= dotContent.replace("}", "");
            dotContent+= existCheck;
            close();
        }
    }

    // Rimuove un nodo scelto
    public void removeNode(String nodeToRemove) {
        // Remove the node line
        dotContent = dotContent.replaceAll("\\b" + nodeToRemove + "\\b.*?;\n", "\n");

        // Remove any edges involving the node being removed
        dotContent = dotContent.replaceAll("\\s*" + nodeToRemove + "\\s*--\\s*\\w+\\s*\\[.*?\\];?\n", "\n");
        dotContent = dotContent.replaceAll("\\s*\\w+\\s*--\\s*" + nodeToRemove + "\\s*\\[.*?\\];?\n", "\n");
    }

    // Chiude il file .dot e lo esegue per ottenere il .png (diverso per windows, serve il path di graphviz)
    public void close() {
        dotContent += "}\n";
        try (FileWriter writer = new FileWriter(dotFile)){
            writer.write(dotContent);
            writer.close();

            String dotPath = "src/main/resources/it/univr/wordautoma_10/Graphviz_11/bin/dot.exe";

            ProcessBuilder pb = new ProcessBuilder(dotPath, "-Tpng", "-o" + imgFile, dotFile);
            Process process = pb.start();
            process.waitFor();

            System.out.println("Graph image generated: " + imgFile);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    /*
    public void test(String key){
        //utilizzando graph manager devo trovare le parti di parola che si colleghino alle successive,
        // prendedo il valore "più lungo possibile" preferisco "aab" ad "aa"
    }*/

}
