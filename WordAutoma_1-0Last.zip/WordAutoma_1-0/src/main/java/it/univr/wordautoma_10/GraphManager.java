package it.univr.wordautoma_10;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GraphManager {

    private List<Node> nodeList;
    private List<Arrow> arrowList;

    public GraphManager() {
        nodeList = new ArrayList<>();
        arrowList = new ArrayList<>();
    }

    public void setNode(String node) {
        if (!containsNode(node)) {
            nodeList.add(new Node(node));
        }
    }

    public void setArrow(String node1Name, String value, String node2Name) {
        Node node1 = getNode(node1Name);
        Node node2 = getNode(node2Name);

        if (node1 == null) {
            node1 = new Node(node1Name);
            nodeList.add(node1);
        }

        if (node2 == null) {
            node2 = new Node(node2Name);
            nodeList.add(node2);
        }

        arrowList.add(new Arrow(node1, value, node2));
    }

    public void setInit(String node) {
        Node n = getNode(node);
        if (n != null) {
            n.setInit(true);
        }
    }

    public void setFinal(String node) {
        Node n = getNode(node);
        if (n != null) {
            n.setFinal(true);
        }
    }

    public Node getNode(String nodeName) {
        for (Node node : nodeList) {
            if (node.isEqual(nodeName)) {
                return node;
            }
        }
        return null;
    }

    private boolean containsNode(String nodeName) {
        return getNode(nodeName) != null;
    }

    public boolean hasInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return true;
            }
        }
        return false;
    }

    public Node nodeInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return node;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("GraphManager:\n");
        sb.append("Nodes:\n");
        for (Node node : nodeList) {
            sb.append("  ").append(node).append("\n");
        }
        sb.append("Arrows:\n");
        for (Arrow arrow : arrowList) {
            sb.append("  ").append(arrow).append("\n");
        }
        return sb.toString();
    }

    /*  NON usato
    public List<Node> hasNext(String node1){
        List<Node> nextNodes= new ArrayList<>();
        for (Arrow arrow: arrowList){
            if(node1.equals(arrow.node2)) //arrow.getNode1Name()
                nextNodes.add(arrow.node2);
        }
        return nextNodes;
    }*/

    public List<Arrow> nextArrow(String nodeName) {
        List<Arrow> nextArrow = new ArrayList<>();
        for (Arrow arrow : arrowList) {
            if (arrow.getNode1Name().equals(nodeName)) {    // prima: if(node1.equals(arrow.node2))
                nextArrow.add(arrow);
            }
        }
        return nextArrow;
    }

    boolean nodeHasValue(String node, String value) {   // usato in graph
        for (Arrow arrow : arrowList) {
            if (arrow.getNode1Name().equals(node) && arrow.getArrowValue().equals(value)) {
                return true;
            }
        }
        return false;
    }

    // restituire il valore associato ad un arco
    public String getEdgeLabel(Node currentNode, char currentValue) {
        // Itera su tutti gli archi per trovare quello che parte dal nodo corrente
        for (Arrow arrow : arrowList) {
            // Verifica se l'arco parte dal nodo corrente e se il valore dell'arco corrisponde al carattere
            if (arrow.getNode1Name().equals(currentNode.getName())
                    && arrow.getArrowValue().equals(Character.toString(currentValue))) {
                return arrow.getArrowValue();  // Restituisce l'etichetta dell'arco
            }
        }
        return null;  // Restituisce null se non c'è un arco corrispondente
    }

    public Node getNextNode(Node currentNode, char currentValue) {
        // Itera su tutti gli archi per trovare quello che parte dal nodo corrente
        for (Arrow arrow : arrowList) {
            // Verifica se l'arco parte dal nodo corrente e se il valore dell'arco corrisponde al carattere
            if (arrow.getNode1Name().equals(currentNode.getName())
                    && arrow.getArrowValue().equals(Character.toString(currentValue))) {
                return arrow.node2;  // Restituisce il nodo successivo
            }
        }
        return null;  // Restituisce null se non c'è un nodo successivo corrispondente
    }

    public static class Node {
        private String name;
        private boolean isInit;
        private boolean isFinal;

        public Node(String name) {
            this.name = name;
            this.isInit = false;
            this.isFinal = false;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isInit() {
            return isInit;
        }

        public void setInit(boolean isInit) {
            if (!isFinal) {
                this.isInit = isInit;
            }
        }

        public boolean isFinal() {
            return isFinal;
        }

        public void setFinal(boolean isFinal) {
            if (!isInit) {
                this.isFinal = isFinal;
            }
        }

        public boolean isEqual(String name) {
            return this.name.equals(name);
        }

        public String toString() {
            return "Node{name='" + name + "', isInit=" + isInit + ", isFinal=" + isFinal + "}";
        }

    }

    public static class Arrow {
        private final Node node1;
        private final String value;
        private final Node node2;

        public Arrow(Node node1, String value, Node node2) {
            this.node1 = node1;
            this.value = value;
            this.node2 = node2;
        }

        public String getNode1Name() {
            return node1.getName();
        }

        public String getNode2Name() {
            return node2.getName();
        }

        public String getArrowValue() {
            return value;
        }

        public String toString() {
            return "Arrow{from=" + node1.getName() + ", value='" + value + "', to=" + node2.getName() + "}";
        }

    }

    // per goSearch versione base
    public void printNodes() {
        System.out.println("Nodes:");
        for (Node node : nodeList) {
            System.out.println("  " + node);
        }
    }

    // per goSearch versione base
    public void printArrows() {
        System.out.println("Arrows:");
        for (Arrow arrow : arrowList) {
            System.out.println("  " + arrow);
        }
    }

    // per goSearch versione base
    public Node pathSelection(String key) {
        Node currentNode = nodeInit();  // Ottieni il nodo iniziale
        if (currentNode == null) {
            System.out.println("Error: No initial state defined.");
            return null;  // Nessun nodo iniziale definito
        }

        System.out.println("Starting pathSelection with key: " + key);

        while (!key.isEmpty()) {
            List<Arrow> nextArrows = nextArrow(currentNode.getName());
            Arrow bestMatch = null;

            // Trova un arco il cui valore corrisponde esattamente all'inizio della chiave
            for (Arrow arrow : nextArrows) {
                if (key.startsWith(arrow.getArrowValue())) {
                    bestMatch = arrow;
                    break;
                }
            }

            if (bestMatch == null) {
                System.out.println("No matching arrow found for remaining key: " + key);
                return null;  // Nessuna transizione corrispondente trovata
            }

            // Avanza al nodo successivo e aggiorna la chiave rimanente
            currentNode = bestMatch.node2;
            key = key.substring(bestMatch.getArrowValue().length());
        }

        // Verifica se il nodo finale è raggiunto con chiave vuota e se è uno stato finale
        if (currentNode.isFinal()) {
            System.out.println("Word accepted at finale node: " + currentNode.getName());
            return currentNode;
        } else {
            System.out.println("Final node is NOT an accepting state.");
            return null;
        }
    }

    // per goSearch versione base
    public Node visualizePathSelection(String key, String outputPath) {
        Node currentNode = nodeInit();
        if (currentNode == null) {
            System.out.println("Error: No initial state defined.");
            return currentNode;
        }

        StringBuilder dotBuilder = new StringBuilder();
        dotBuilder.append("digraph {\n");
        dotBuilder.append("\tnode[fontname=\"Open Sans\", shape=\"circle\"];\n");

        String previousNodeName = null;

        while (!key.isEmpty()) {
            List<Arrow> nextArrows = nextArrow(currentNode.getName());
            Arrow bestMatch = null;

            for (Arrow arrow : nextArrows) {
                if (key.startsWith(arrow.getArrowValue())) {
                    bestMatch = arrow;
                    break;
                }
            }

            if (bestMatch == null) {
                System.out.println("No matching arrow found for remaining key: " + key);
                return currentNode;
            }

            // Color the current node and arrow
            dotBuilder.append("\t").append(currentNode.getName()).append(" [style=filled, fillcolor=green];\n");
            dotBuilder.append("\t").append(bestMatch.getNode1Name())
                    .append(" -> ").append(bestMatch.getNode2Name())
                    .append(" [label=\"").append(bestMatch.getArrowValue())
                    .append("\", color=green];\n");

            // Advance to the next node
            previousNodeName = currentNode.getName();
            currentNode = bestMatch.node2;
            key = key.substring(bestMatch.getArrowValue().length());
        }

        // Color the final node if it's an accepting state
        if (currentNode.isFinal()) {
            dotBuilder.append("\t").append(currentNode.getName())
                    .append(" [style=filled, fillcolor=green];\n");
        } else {
            System.out.println("Final node is not an accepting state.");
            return currentNode;
        }

        // Add the remaining nodes and arrows to the DOT file
        for (Node node : nodeList) {
            if (!node.getName().equals(previousNodeName)) {
                dotBuilder.append("\t").append(node.getName()).append(";\n");
            }
        }

        for (Arrow arrow : arrowList) {
            if (!arrow.getNode1Name().equals(previousNodeName)) {
                dotBuilder.append("\t").append(arrow.getNode1Name())
                        .append(" -> ").append(arrow.getNode2Name())
                        .append(" [label=\"").append(arrow.getArrowValue())
                        .append("\"];\n");
            }
        }

        dotBuilder.append("}\n");

        // Write the DOT file
        try (FileWriter writer = new FileWriter(outputPath)) {
            writer.write(dotBuilder.toString());
            System.out.println("DOT file generated at: " + outputPath);
        } catch (IOException e) {
            System.out.println("Error writing DOT file: " + e.getMessage());
        }
        return currentNode;
    }

}