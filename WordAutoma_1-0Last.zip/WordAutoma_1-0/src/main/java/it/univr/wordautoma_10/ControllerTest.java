package it.univr.wordautoma_10;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import java.time.LocalTime;

// Controller for Scene 2
public class ControllerTest {

    @FXML
    public Text mainTitle;

    @FXML
    private Text pathDisplay; // Aggiungiamo questo campo per collegarlo alla GUI

    @FXML
    private Text valueDisplay; // Aggiungiamo questo campo per visualizzare i valori

    @FXML
    private TextField searchTextField;

    @FXML
    private ImageView prevImg;

    public GraphManager graphManager;  // Assumendo che graphManager sia inizializzato in qualche altro modo

    public String initialNode;  // Nodo iniziale passato come nome

    private final String nomeFile= "graph";

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    public void initialize() {
        try {
            uploadImage();
        } catch (Exception e) {
            mainTitle.setText("Error loading image: " + e.getMessage());
        }
    }

    public void uploadImage() {
        try {
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);
            Image newImage = new Image("file:" + PATH + nomeFile + ".png");
            prevImg.setImage(newImage);
        } catch (Exception e) {
            mainTitle.setText("Failed to load graph image.");
            throw new RuntimeException(e);
        }
    }

    // Servono per passare di scena il grafo
    public void setGraphManager(GraphManager graphManager) {
        this.graphManager = graphManager;
    }

    public void setInitialNode(String initialNode) {
        this.initialNode = initialNode;
    }

    /*@FXML
    public void goSearch() {
        String searchText = searchTextField.getText().trim();
        if (searchText.isEmpty()) {
            mainTitle.setText("Please enter a word to search.");
            return;
        }

        if (graphManager == null) {
            mainTitle.setText("GraphManager is not initialized.");
            return;
        }

        // Stampa i nodi e gli archi
        graphManager.printNodes();
        graphManager.printArrows();

        // Esegui la ricerca della parola
        GraphManager.Node finalNode = graphManager.pathSelection(searchText);
        //GraphManager.Node finalNode = graphManager.visualizePathSelection(searchText, PATH + nomeFile + ".dot");

        // Verifica se la parola è stata accettata o rifiutata
        if (finalNode != null && finalNode.isFinal()) {
            mainTitle.setText("The word '" + searchText + "' is accepted.");
        } else {
            mainTitle.setText("The word '" + searchText + "' is rejected.");
        }

        // Ricarica l'immagine aggiornata del grafo
        uploadImage();
    }*/

    @FXML
    public void goSearch() {
        String searchText = searchTextField.getText().trim();
        if (searchText.isEmpty()) {
            mainTitle.setText("Please enter a word to search.");
            return;
        }

        if (graphManager == null) {
            mainTitle.setText("GraphManager is not initialized.");
            return;
        }

        // Esegui la ricerca della parola e ottieni il percorso
        GraphManager.Node currentNode = graphManager.getNode(initialNode); // Inizia dal nodo iniziale
        GraphManager.Node finalNode = null;

        // Inizializza i costruttori di stringhe per nodi e valori
        StringBuilder nodesBuilder = new StringBuilder();
        StringBuilder valuesBuilder = new StringBuilder();

        // Itera attraverso ciascun carattere della parola di ricerca
        for (int pos = 0; pos < searchText.length(); pos ++) {
            if (pos > 0) {
                nodesBuilder.append(" ");  // Aggiunge uno spazio tra i nodi
                valuesBuilder.append(" "); // Aggiunge uno spazio tra i valori
            }

            char currentValue = searchText.charAt(pos);

            if (currentNode != null) {
                // Aggiungi il nodo corrente (il nome del nodo) alla stringa dei nodi
                nodesBuilder.append(currentNode.getName());

                // Supponiamo che il valore che desideri visualizzare sia l'etichetta dell'arco al prossimo nodo
                String nodeValue = graphManager.getEdgeLabel(currentNode, currentValue); // Ottieni il valore dell'arco

                if (nodeValue != null) {
                    valuesBuilder.append(nodeValue);  // Aggiunge il valore dell'arco corrente
                } else {
                    valuesBuilder.append(" ");  // Se il valore non esiste, aggiungi uno spazio
                }

                // Avanza al nodo successivo seguendo il carattere dell'input
                currentNode = graphManager.getNextNode(currentNode, currentValue);
                finalNode = currentNode;  // Aggiorna il nodo finale
            }
        }

        // Dopo aver attraversato tutti i caratteri, aggiungi l'ultimo nodo alla stringa
        if (currentNode != null) {
            nodesBuilder.append(" ").append(currentNode.getName());
        }

        // Aggiungi il ticket o la X a seconda se la parola è accettata o rifiutata
        if (finalNode != null && finalNode.isFinal()) {
            mainTitle.setText("The word '" + searchText + "' is accepted.");
            valuesBuilder.append("  ✔"); // Aggiunge il ticket alla fine se accettata
        } else {
            mainTitle.setText("The word '" + searchText + "' is rejected.");
            valuesBuilder.append("  X"); // Aggiunge la X alla fine se rifiutata
        }

        // Mostra il percorso e i valori nei Text appositi
        valueDisplay.setText(valuesBuilder.toString());
        pathDisplay.setText(nodesBuilder.toString());

        // Pulisce il campo di ricerca
        searchTextField.clear();

        // Ricarica l'immagine aggiornata del grafo
        uploadImage();
    }

}
