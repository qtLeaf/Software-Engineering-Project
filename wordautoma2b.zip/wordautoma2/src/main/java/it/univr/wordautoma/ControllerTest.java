package it.univr.wordautoma;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;
import java.time.LocalTime;

public class ControllerTest {

    @FXML
    public Text mainTitle;

    @FXML
    public TextField myText;

    @FXML
    private ImageView prevImg;

    private final String PATH= "src/main/resources/it/univr/wordautoma/automas/";

    private String nomeFile;

    public void initialize() {
        Platform.runLater(this::uploadImage);
    }

    public void uploadImage() {
        LocalTime time = LocalTime.now();
        System.out.println("Current Time: " + time);
        Image newImage = new Image("file:" + PATH + nomeFile + ".png");
        prevImg.setImage(newImage);
    }

    public void setFileName(String nomeFile){
        this.nomeFile= nomeFile;
    }

    @FXML
    public void goBack(javafx.event.ActionEvent event) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("midScene.fxml"));
        Parent root = loader.load();

        ControllerMid is = loader.getController();
        is.setFileName(nomeFile);

        // Set the new scene to the stage
        Stage stage = (Stage) ((javafx.scene.control.Button) event.getSource()).getScene().getWindow();
        stage.getScene().setRoot(root);
    }

}
