package it.univr.wordautoma;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalTime;

public class ControllerMid {

    private Graph graph;

    @FXML
    public TextArea outputTextArea;

    @FXML
    private TextField promptNode;

    @FXML
    public TextField promptValue;

    @FXML
    private TextField promptNode2;

    @FXML
    private ImageView prevImg;

    @FXML
    public Button submitAddlink;

    @FXML
    public Button submitButton;

    @FXML
    public ComboBox<String> StateInit = new ComboBox<>();

    @FXML
    public ComboBox<String> StateEnd = new ComboBox<>();

    ObservableList<String> items = FXCollections.observableArrayList();

    private final String PATH= "src/main/resources/it/univr/wordautoma/automas/";

    private String nomeFile;

    public void initialize() {
        Platform.runLater(() -> {
            graph = new Graph(nomeFile);

            promptNode.setOnAction(event -> promptNode.setDisable(false));
            promptValue.setOnAction(event -> promptValue.setDisable(false));
            promptNode2.setOnAction(event -> promptNode2.setDisable(false));

            // Add listeners to text fields to validate the submitAddlink button
            promptNode.textProperty().addListener((observable, oldValue, newValue) -> validateAddLinkButton());
            promptValue.textProperty().addListener((observable, oldValue, newValue) -> validateAddLinkButton());
            promptNode2.textProperty().addListener((observable, oldValue, newValue) -> validateAddLinkButton());

            updateImage();

            presetAreaText();
            viewNode();

            StateInit.setItems(items);
            StateEnd.setItems(items);

            StateInit.valueProperty().addListener((observable, oldValue, newValue) -> validateSubmitButton());
            StateEnd.valueProperty().addListener((observable, oldValue, newValue) -> validateSubmitButton());

            submitButton.setDisable(true);
            submitAddlink.setDisable(true);  // Initially disable the add link button
        });
    }

    private void validateSubmitButton() {
        submitButton.setDisable(StateInit.getValue() == null || StateEnd.getValue() == null);
    }

    private void validateAddLinkButton() {
        submitAddlink.setDisable(promptNode.getText().isEmpty() ||
                promptValue.getText().isEmpty() ||
                promptNode2.getText().isEmpty());
    }

    @FXML
    public void onSubmit(javafx.event.ActionEvent event) throws IOException {
        if (StateInit.getValue() != null && StateEnd.getValue() != null) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("testScene.fxml"));
            Parent root = loader.load();

            ControllerTest is = loader.getController();
            is.setFileName(nomeFile);

            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.getScene().setRoot(root);
        } else {
            System.out.println("Please select both StateInit and StateEnd.");
        }
    }

    public void onSubmitLink() {
        String selectedNode = promptNode.getText();
        String selectedValue = promptValue.getText();
        String selectedNode2 = promptNode2.getText();

        if (!selectedNode.isEmpty() && !selectedNode2.isEmpty() && !selectedValue.isEmpty()) {
            System.out.println("Link submitted between nodes: " + selectedNode +
                    " and " + selectedNode2 + " value " + selectedValue);
            System.out.println("The event was done correctly.");
            promptNode.clear();
            promptValue.clear();
            promptNode2.clear();
            String newText = nomeFile + " - added: " + selectedNode + " ~ " + selectedValue + " ~ " + selectedNode2 + "\n";

            graph.addArrow(selectedNode, selectedValue, selectedNode2);
            updateImage();

            outputTextArea.appendText(newText);

            appendNodeToList(selectedNode);
            appendNodeToList(selectedNode2);
        } else {
            System.out.println("Please fill all fields before submitting.");
        }
    }

    public void updateImage() {
        LocalTime time = LocalTime.now();
        System.out.println("Current Time: " + time);
        Image newImage = new Image("file:" + PATH + nomeFile + ".png");
        prevImg.setImage(newImage);
    }

    public void setFileName(String nomeFile){
        this.nomeFile= nomeFile;
    }

    private void presetAreaText(){
        outputTextArea.setEditable(false);
        outputTextArea.setMouseTransparent(true);
        outputTextArea.setFocusTraversable(false);
    }

    @FXML
    public void viewNode() {
        StateInit.setItems(items);
        StateEnd.setItems(items);
        try (BufferedReader reader = new BufferedReader(new FileReader(PATH + "nodesName.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                items.add(line);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void appendNodeToList(String nodeName) {
        if (!nodeExist(PATH + "nodesName.txt", nodeName)) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(PATH + "nodesName.txt", true))) {
                writer.write(nodeName + System.lineSeparator());
                items.add(nodeName);
            } catch (IOException e) {
                System.out.println("An error occurred while writing to the file.");
            }
        }
    }

    public boolean nodeExist(String filePath, String nodeToFind) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals(nodeToFind)) {
                    return true;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return false;
    }
}
