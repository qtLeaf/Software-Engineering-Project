package it.univr.wordautoma;

import java.io.*;

public class Graph {

    //private int nodes;
    private String dotContent;

    String dotFile;
    String imgFile;

    private final String PATH="src/main/resources/it/univr/wordautoma/automas/";

    public Graph(String fileName) {
        if(!graphExist(PATH + "filesName.txt", fileName)) {
            appendGrpahToList(fileName);
            //must be installed font to operate with them
            dotContent = "graph " + fileName + " {\n" + "\tnode[fontname=\"Arial\", shape=\"circle\"]\n";
            //install package for other font
            //dotContent = "graph " + fileName + " {\n" + "\tnode[fontname=\"Open Sans\", shape=\"circle\"]\n";
            this.dotFile= PATH + fileName + ".dot";
            this.imgFile= PATH + fileName + ".png";
            this.close();
        }else{
            this.dotFile= PATH + fileName + ".dot";
            this.imgFile= PATH + fileName + ".png";

            //to rewrite on modify existing model
           // dotContent = restoreGraph();
        }
    }

    //private String restoreGraph() {}

    // Aggiungo un arco tra due nodi inseriti (posso aggiungere qui in una lista con gli archi)
    public void addArrow(String node1, String value, String node2) {
        //rimovere ultima riga
        String esisteCheck = "\t" + node1 + "--" + node2 + "[label=\"" + value + "\"]\n";
        if(!dotContent.contains(esisteCheck)){
            dotContent = dotContent.replace("}", "");
            dotContent+= esisteCheck;
            close();
        }

    }//se esiste la non la aggiungo

    public void setNodeInit(String node){
        dotContent += "\t" + node + "[shape=\"circle\"]\n";
    }

    // Aggiunge graficamente un cerchio ad un nodo per renderlo finale
    public void setNodeFinal(String node){
        dotContent += "\t" + node + "[shape=\"doublecircle\"]\n";
    }

    /*
    // Rimuove un nodo scelto
    public void removeNode(String nodeToRemove) {
        // Remove the node line
        dotContent = dotContent.replaceAll("\\b" + nodeToRemove + "\\b.*?;\n", "\n");

        // Remove any edges involving the node being removed
        dotContent = dotContent.replaceAll("\\s*" + nodeToRemove + "\\s*--\\s*\\w+\\s*\\[.*?\\];?\n", "\n");
        dotContent = dotContent.replaceAll("\\s*\\w+\\s*--\\s*" + nodeToRemove + "\\s*\\[.*?\\];?\n", "\n");
    }
    */

    // Chiude il file .dot e lo esegue per ottenere il .png (diverso per windows, serve il path di graphviz)
    public void close() {
        dotContent += "}\n";
        try {
            // Write to the DOT file
            FileWriter writer = new FileWriter(dotFile);
            writer.write(dotContent);
            writer.close();

            // Correct path to the dot executable (remove the semicolon)
            String dotPath = "src/main/resources/it/univr/wordautoma/Graphviz_11/bin/dot.exe";

            // Setup ProcessBuilder
            ProcessBuilder pb = new ProcessBuilder(dotPath, "-Tpng", dotFile, "-o", imgFile);
            pb.redirectErrorStream(true);  // Redirect errors and output to standard output

            // Start the process
            Process process = pb.start();

            // Debug output from the process
            try (InputStream is = process.getInputStream();
                 InputStreamReader isr = new InputStreamReader(is);
                 BufferedReader br = new BufferedReader(isr)) {
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);  // Print all output from the process
                }
            }

            // Wait for the process to complete
            int exitValue = process.waitFor();
            if (exitValue == 0) {
                System.out.println("Graph image generated: " + imgFile);
            } else {
                System.out.println("Graphviz exited with error code: " + exitValue);
            }
        } catch (IOException | InterruptedException e) {
            //e.printStackTrace();
            System.out.println("I/O error or interrupted while generating graph");
        }
    }

    // Controlla se il file è nel file contenente i file
    public boolean graphExist(String filePath, String fileToFind){
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals(fileToFind)) {
                    return true;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    // Aggiunge il nome del file nel file contente i nomi di file già esistenti
    private void appendGrpahToList(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PATH + "filesName.txt", true))) {
            writer.write(fileName + System.lineSeparator());
        } catch (IOException e) {
            System.out.println("Si trova gia' in lista");    }
    }

}
