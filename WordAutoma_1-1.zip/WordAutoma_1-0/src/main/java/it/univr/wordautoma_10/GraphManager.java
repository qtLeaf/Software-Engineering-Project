package it.univr.wordautoma_10;

import java.util.ArrayList;
import java.util.List;

public class GraphManager {

    private final List<Node> nodeList;      // List to hold nodes in the graph
    private final List<Arrow> arrowList;    // List to hold arrows (edges) between nodes

    public GraphManager(){
        nodeList = new ArrayList<>();    // Initialize the node list
        arrowList = new ArrayList<>();   // Initialize the arrow list
    }

    // Adds a node to the graph
    public void setNode(String node){
        if (findNode(node) == null) {    // Check if the node doesn't already exist
            nodeList.add(new Node(node));
        }
    }

    // Adds an arrow (edge) between two nodes
    public void setArrow(String node1, String value, String node2){
        Node startNode = findNode(node1);
        Node endNode = findNode(node2);

        if (startNode != null && endNode != null) {   // Ensure both nodes exist
            Arrow arrow = new Arrow(startNode, value, endNode);
            arrowList.add(arrow);
        }
    }

    // Sets a node as the initial node
    public void setInit(String node){
        Node n = findNode(node);
        if (n != null) {
            n.setInit(true);
        }
    }

    // Sets a node as the final node
    public void setFinal(String node){
        Node n = findNode(node);
        if (n != null) {
            n.setFinal(true);
        }
    }

    // Finds a node by name
    public Node findNode(String nodeName) {
        for (Node node : nodeList) {
            if (node.getName().equals(nodeName)) {
                return node;
            }
        }
        return null;  // Return null if the node doesn't exist
    }

    public List<Node> getNodes() {
        return nodeList;
    }

    // Represents an arrow (edge) in the graph
    public class Arrow {
        private Node startNode;
        private String value;
        private Node endNode;

        public Arrow(Node startNode, String value, Node endNode) {
            this.startNode = startNode;
            this.value = value;
            this.endNode = endNode;
        }

        @Override
        public String toString() {
            return startNode.getName() + " --" + value + "--> " + endNode.getName();
        }

        public String getValue() {
            return value;
        }

        public Node getStartNode() {
            return startNode;
        }

        public Node getEndNode() {
            return endNode;
        }
    }

    // Represents a node in the graph
    public static class Node {
        private String name;
        private boolean isInit;
        private boolean isFinal;

        public Node(String name) {
            this.name = name;
            this.isInit = false;
            this.isFinal = false;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isInit() {
            return isInit;
        }

        public void setInit(boolean isInit) {
            this.isInit = isInit;
        }

        public boolean isFinal() {  //usato in CTest
            return isFinal;
        }

        public void setFinal(boolean isFinal) {
            this.isFinal = isFinal;
        }

        @Override
        public String toString() {
            return "Node{name='" + name + "', isInit=" + isInit + ", isFinal=" + isFinal + "}";
        }
    }

}
