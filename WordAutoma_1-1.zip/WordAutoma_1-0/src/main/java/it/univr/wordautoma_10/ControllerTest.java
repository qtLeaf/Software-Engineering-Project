package it.univr.wordautoma_10;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import java.time.LocalTime;

// Controller for Scene 2
public class ControllerTest {

    @FXML
    public Text mainTitle;

    @FXML
    private TextField searchTextField;

    @FXML
    private ImageView prevImg;

    private final String nomeFile= "graph";

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    private Graph graph;  // Assumendo che graphManager sia inizializzato in qualche altro modo

    private String initialNode;  // Nodo iniziale passato come nome

    public void initialize() {
        uploadImage();
    }

    public void uploadImage() {
        LocalTime time = LocalTime.now();
        System.out.println("Current Time: " + time);
        Image newImage = new Image("file:" + PATH + nomeFile + ".png");
        prevImg.setImage(newImage);
    }

    /*
    @FXML   //non si salva la classe di graph!!!!!
    public void goBack(javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("midScene.fxml"));
        Parent root = loader.load();

        // Set the new scene to the stage
        Stage stage = (Stage) ((javafx.scene.control.Button) event.getSource()).getScene().getWindow();
        stage.getScene().setRoot(root);
    }*/

    /*public void setInitialNode(GraphManager.Node initialNode) {
        this.initialNode = initialNode;
    }
    */
    public void setInitialNode(String initialNode) {
        this.initialNode = initialNode;
    }

    public void setGraphManager(Graph graph) {
        this.graph = graph;
    }

    @FXML
    public void goSearch() {
        // Verifica il valore di initialNode
        if (initialNode == null || initialNode.trim().isEmpty()) {
            mainTitle.setText("Initial node is not set.");
            return;
        }

        System.out.println("Initial Node: " + initialNode);

        // Ottieni il nodo iniziale
        GraphManager.Node currentNode = graph.findNode(initialNode);
        if (currentNode == null) {
            mainTitle.setText("Initial node not found.");
            return;
        }

        System.out.println("Current Node: " + currentNode.getName());

        // Continua con la ricerca
        String searchText = searchTextField.getText().trim();
        if (searchText.isEmpty()) {
            mainTitle.setText("Please enter a word to search.");
            return;
        }

        String remainingText = searchText;
        boolean accepted = false;

        while (remainingText.length() > 0) {
            GraphManager.Arrow transition = graph.findTransition(currentNode, remainingText);

            if (transition == null) {
                break; // Nessuna transizione trovata, quindi la parola viene rifiutata
            }

            remainingText = remainingText.substring(transition.getValue().length());
            currentNode = transition.getEndNode();

            if (remainingText.isEmpty() && currentNode.isFinal()) {
                accepted = true;
                break;
            }
        }

        if (accepted) {
            mainTitle.setText("The word is accepted.");
        } else {
            mainTitle.setText("The word is rejected.");
        }
    }

}
