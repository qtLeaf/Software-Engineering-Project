package it.univr.wordautoma_10;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import java.time.LocalTime;

// Controller for Scene 2
public class ControllerTest {

    @FXML
    public Text mainTitle;

    @FXML
    private TextField searchTextField;

    @FXML
    private Text pathDisplay; // Aggiungiamo questo campo per collegarlo alla GUI

    @FXML
    private Text valueDisplay; // Aggiungiamo questo campo per visualizzare i valori



    @FXML
    private ImageView prevImg;

    public Graph graph;  // Assumendo che graphManager sia inizializzato in qualche altro modo

    public String initialNode;  // Nodo iniziale passato come nome

    private final String nomeFile= "graph";

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    public void initialize() {
        try {
            uploadImage();
        } catch (Exception e) {
            mainTitle.setText("Error loading image: " + e.getMessage());
        }
    }

    //Servono per passare di scena il grafo
    public void setGraph(Graph graph) {
        this.graph = graph;
    }

    public void setInitialNode(String initialNode) {
        this.initialNode = initialNode;
    }

    @FXML
    public void goSearch() {
        String searchText = searchTextField.getText().trim();
        if (searchText.isEmpty()) {
            mainTitle.setText("Please enter a word to search.");
            return;
        }


        // Stampa i nodi e gli archi
        //graphManager.printNodes();
        //graphManager.printArrows();

        // Esegui la ricerca della parola
        StringBuilder result[] = graph.test(searchText);

        uploadNewImage();
        valueDisplay.setText(result[0].toString());
        pathDisplay.setText(result[1].toString());

    }

    public void uploadImage() {
        try {
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);
            Image newImage = new Image("file:" + PATH + nomeFile + ".png");
            prevImg.setImage(newImage);
        } catch (Exception e) {
            mainTitle.setText("Failed to load graph image.");
            e.printStackTrace();
        }
    }

    public void uploadNewImage() {
        try {
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);
            Image newImage = new Image("file:" + PATH + "test" + nomeFile + ".png");
            prevImg.setImage(newImage);
        } catch (Exception e) {
            mainTitle.setText("Failed to load graph image.");
            e.printStackTrace();
        }
    }
}

