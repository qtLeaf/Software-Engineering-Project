package it.univr.wordautoma_10;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().
                getResource("startScene.fxml")));
        primaryStage.setTitle("Word Automa");
        Scene scene = new Scene(root, 800, 700);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().
                getResource("style.css")).toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /*
    // launch App
    public static void main(String[] args) {
        launch(args);
    }

    /*
    // Test statico
    public static void main(String[] args) {
        GraphManager graphManager = new GraphManager();

        // Configura i nodi
        graphManager.setNode("q0");
        graphManager.setNode("q1");
        graphManager.setNode("q2");
        graphManager.setNode("q3");
        graphManager.setNode("q4");

        // Configura gli archi
        graphManager.setArrow("q0", "aab", "q1");
        graphManager.setArrow("q0", "abbb", "q2");
        graphManager.setArrow("q2", "aba", "q1");
        graphManager.setArrow("q1", "b", "q2");
        graphManager.setArrow("q1", "a", "q3");
        graphManager.setArrow("q2", "b", "q3");
        graphManager.setArrow("q3", "bb", "q4");
        graphManager.setArrow("q4", "b", "q2");
        graphManager.setArrow("q4", "a", "q1");
        graphManager.setArrow("q3", "abb", "q3");

        // Configura nodi iniziali e finali
        graphManager.setInit("q0");
        graphManager.setFinal("q3");
        graphManager.setFinal("q4");

        // Stampa la configurazione dell'automa
        System.out.println("Graph configuration:");
        graphManager.printNodes();
        graphManager.printArrows();

        // Test con parola 'aababbbb'
        System.out.println("Testing word: 'aababbbb'");
        GraphManager.Node result1 = graphManager.pathSelection("aababbbb");
        System.out.println("    Is path 'aababbbb' valid? " + result1);

        // Test con parola 'abbbaba'
        System.out.println("Testing word: 'abbbaba'");
        GraphManager.Node result2 = graphManager.pathSelection("abbbaba");
        System.out.println("    Is path 'aababbbb' valid? " + result2);

        // Test con parola 'abbbabaaba'
        System.out.println("Testing word: 'abbbabaaba'");
        GraphManager.Node result3 = graphManager.pathSelection("abbbabaaba");
        System.out.println("    Is path 'abbbabaaba' valid? " + result3);

        //altri test ...
    }*/

}
