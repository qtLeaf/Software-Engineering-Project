package it.univr.wordautoma_10;

import java.util.ArrayList;
import java.util.List;

public class GraphManager {

    private List<Node> nodeList;
    private List<Arrow> arrowList;

    public GraphManager() {
        nodeList = new ArrayList<>();
        arrowList = new ArrayList<>();
    }

    public Node setNode(String nodeName) {
        Node existingNode = getNode(nodeName);
        if (existingNode == null) {
            existingNode = new Node(nodeName);
            nodeList.add(existingNode);
        }
        return existingNode;
    }

    public void setArrow(String node1Name, String value, String node2Name) {
        Node node1 = setNode(node1Name);
        Node node2 = setNode(node2Name);
        arrowList.add(new Arrow(node1, value, node2));
    }

    public void setInit(String nodeName) {
        Node node = getNode(nodeName);
        if (node != null) {
            node.setInit(true);
        }
    }

    public void setFinal(String nodeName) {
        Node node = getNode(nodeName);
        if (node != null) {
            node.setFinal(true);
        }
    }

    public String[] getFinals() {
        List<String> finalNodes = new ArrayList<>();
        for (Node node : nodeList) {
            if (node.isFinal()) {
                finalNodes.add(node.getName());
            }
        }
        return finalNodes.toArray(new String[0]);
    }

    private Node getNode(String nodeName) {
        for (Node node : nodeList) {
            if (node.isEqual(nodeName)) {
                return node;
            }
        }
        return null;
    }

    private boolean containsNode(String nodeName) {
        return getNode(nodeName) != null;
    }

    public String hasInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return node.getName();
            }
        }
        return null;
    }

    public Node nodeInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return node;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("GraphManager:\n");
        sb.append("Nodes:\n");
        for (Node node : nodeList) {
            sb.append("  ").append(node).append("\n");
        }
        sb.append("Arrows:\n");
        for (Arrow arrow : arrowList) {
            sb.append("  ").append(arrow).append("\n");
        }
        return sb.toString();
    }

    public List<Node> hasNext(String node1) {
        List<Node> nextNodes = new ArrayList<>();
        for (Arrow arrow : arrowList) {
            if (node1.equals(arrow.node2.getName())) {
                nextNodes.add(arrow.node2);
            }
        }
        return nextNodes;
    }

    public List<Arrow> nextArrow(String node1) {
        List<Arrow> nextArrows = new ArrayList<>();
        for (Arrow arrow : arrowList) {
            if (node1.equals(arrow.getNode1Name())) {
                nextArrows.add(arrow);
            }
        }
        return nextArrows;
    }

    public boolean nodeHasValue(String node, String value) {
        for (Arrow arrow : arrowList) {
            if (arrow.getNode1Name().equals(node) && arrow.getArrowValue().equals(value)) {
                return true;
            }
        }
        return false;
    }

    public static class Node {
        private String name;
        private boolean isInit;
        private boolean isFinal;

        public Node(String name) {
            this.name = name;
            this.isInit = false;
            this.isFinal = false;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isInit() {
            return isInit;
        }

        public void setInit(boolean isInit) {
            if (!isFinal) {
                this.isInit = isInit;
            }
        }

        public boolean isFinal() {
            return isFinal;
        }

        public void setFinal(boolean isFinal) {
            if (!isInit) {
                this.isFinal = isFinal;
            }
        }

        public boolean isEqual(String name) {
            return this.name.equals(name);
        }

        @Override
        public String toString() {
            return "Node{name='" + name + "', isInit=" + isInit + ", isFinal=" + isFinal + "}";
        }
    }

    public class Arrow {
        private Node node1;
        private String value;
        private Node node2;

        public Arrow(Node node1, String value, Node node2) {
            this.node1 = node1;
            this.value = value;
            this.node2 = node2;
        }

        @Override
        public String toString() {
            return "Arrow{node1=" + node1.getName() + ", value='" + value + "', node2=" + node2.getName() + "}";
        }

        public String toStringPath() {
            return "[" + node1.getName() + "] - " + value + " > [" + node2.getName() + "]";
        }

        public String getNode1Name() {
            return node1.getName();
        }

        public String getNode2Name() {
            return node2.getName();
        }

        public String getArrowValue() {
            return value;
        }

        public Node getNode1() {
            return node1;
        }

        public Node getNode2() {
            return node2;
        }
    }

    public void printNodes() {
        System.out.println("Nodes:");
        for (Node node : nodeList) {
            System.out.println("  " + node);
        }
    }

    public void printArrows() {
        System.out.println("Arrows:");
        for (Arrow arrow : arrowList) {
            System.out.println("  " + arrow);
        }
    }

    public void printArrowsNodes() {
        System.out.println("Arrows Node:");
        for (Arrow arrow : arrowList) {
            System.out.println("  " + arrow.getNode1() + " " + arrow.getNode2() + "\n");
        }
    }

    // Method to verify automaton validity (commented out)
    /*
    public boolean isValidAutoma(String key) {
        Node currentNode = nodeInit();
        if (currentNode == null) {
            System.out.println("No initial node found.");
            return false; // No initial node
        }

        Node finalNode = pathSelection(key);
        if (finalNode == null) {
            System.out.println("No valid path found for the key: " + key);
            return false; // No valid path found
        }

        if (!finalNode.isFinal()) {
            System.out.println("The final node is not an accepting state.");
            return false; // Final node is not an accepting state
        }

        if (!key.isEmpty()) {
            System.out.println("The entire key was not consumed: remaining key = " + key);
            return false; // Key was not completely consumed
        }

        return true; // The automaton is valid, and the key is accepted
    }
    */

    public String pathSelection(String key) {
        String path = "";
        Node currentNode = nodeInit();  // Get the initial node
        if (currentNode == null) {
            System.out.println("Error: No initial state defined.");
            return null;  // No initial node defined
        }

        System.out.println("Starting pathSelection with key: " + key);

        while (!key.isEmpty()) {
            List<Arrow> nextArrows = nextArrow(currentNode.getName());
            Arrow bestMatch = null;

            // Find an arrow whose value exactly matches the beginning of the key
            for (Arrow arrow : nextArrows) {
                if (key.startsWith(arrow.getArrowValue())) {
                    bestMatch = arrow;
                    break;
                }
            }

            if (bestMatch == null) {
                System.out.println("No matching arrow found for remaining key: " + key);
                return path + "X No matching arrow found for remaining key: " + key;  // No matching transition found
            }

            // Move to the next node and update the remaining key
            path += bestMatch.toStringPath() + " | ";
            currentNode = bestMatch.getNode2();
            key = key.substring(bestMatch.getArrowValue().length());
        }

        // Check if the final node is reached with an empty key and if it is a final state
        if (currentNode.isFinal()) {
            System.out.println("Word accepted at final node: " + currentNode.getName());
            return path;
        } else {
            System.out.println("Final node is NOT an accepting state.");
            return path + "X Final node is NOT an accepting state";
        }
    }
}
