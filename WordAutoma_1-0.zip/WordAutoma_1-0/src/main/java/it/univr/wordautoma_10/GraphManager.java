package it.univr.wordautoma_10;

import java.util.ArrayList;
import java.util.List;

public class GraphManager {

    private List<Node> arrowList;
    private List<Node> nodeList;

    public GraphManager(){
        nodeList= new ArrayList<>();
    }

    public void setNode(String node){
        nodeList.add(new Node(node));
    }

    public void setArrow(String node1, String value, String node2){

    }

    public void setInit(String node){

    }

    public void setFinal(String node){

    }

    private class Node {
        private String name;
        private boolean isInit;
        private boolean isFinal;

        public Node(String name) {
            this.name = name;
            this.isInit = false;
            this.isFinal = false;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isInit() {
            return isInit;
        }

        public void setInit(boolean isInit) {
            this.isInit = isInit;
        }

        public boolean isFinal() {
            return isFinal;
        }

        public void setFinal(boolean isFinal) {
            this.isFinal = isFinal;
        }

        @Override
        public String toString() {
            return "Node{name='" + name + "', isInit=" + isInit + ", isFinal=" + isFinal + "}";
        }
    }

}
