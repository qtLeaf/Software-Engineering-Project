package it.univr.wordautoma_10;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().
                getResource("startScene.fxml")));
        primaryStage.setTitle("Word Automa");
        Scene scene = new Scene(root, 800, 700);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().
                getResource("style.css")).toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }
/*
    // launch App
    public static void main(String[] args) {
        launch(args);
    }
*/

    // Test statico
    public static void main(String[] args) {
        GraphManager graphManager = new GraphManager();

        // Configura i nodi e gli archi
        graphManager.setNode("a");
        graphManager.setNode("z");
        graphManager.setArrow("a", "3", "z");
        graphManager.setInit("a");
        graphManager.setFinal("z");

        graphManager.printNodes();
        graphManager.printArrows();

        // Test della validità dell'automa
        System.out.println("Testing word '3':");
        boolean isValid = graphManager.isValidAutoma("3");
        System.out.println("Is path '3' valid? " + isValid);

        //altri test ...
    }

}
