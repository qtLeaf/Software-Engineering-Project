package it.univr.wordautoma_10;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import java.time.LocalTime;

// Controller for Scene 2
public class ControllerTest {

    @FXML
    public Text mainTitle;

    @FXML
    private TextField searchTextField;

    @FXML
    private ImageView prevImg;

    private Graph graph;  // Assumendo che graphManager sia inizializzato in qualche altro modo

    private String initialNode;  // Nodo iniziale passato come nome

    private final String nomeFile= "graph";

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    // Aggiungi questa variabile per controllare se la ricerca è stata accettata
    private boolean isSearchAccepted = false;

    public void initialize() {
        try {
            uploadImage();
        } catch (Exception e) {
            mainTitle.setText("Error loading image: " + e.getMessage());
        }
    }

    public void uploadImage() {
        try {
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);
            Image newImage = new Image("file:" + PATH + nomeFile + ".png");
            prevImg.setImage(newImage);
        } catch (Exception e) {
            mainTitle.setText("Failed to load graph image.");
            e.printStackTrace();
        }
    }

    public void setGraphManager(Graph graph) {
        this.graph = graph;
    }

    public void setInitialNode(String initialNode) {
        this.initialNode = initialNode;
    }

    @FXML
    public void goSearch() {
        if (isSearchAccepted) {
            mainTitle.setText("Search has already been accepted.");
            return; // Non permette ulteriori ricerche
        }

        if (initialNode == null || initialNode.trim().isEmpty()) {
            mainTitle.setText("Initial node is not set.");
            return;
        }

        GraphManager.Node currentNode = graph.findNode(initialNode);

        if (currentNode == null) {
            mainTitle.setText("Initial node not found.");
            return;
        }

        String searchText = searchTextField.getText().trim();
        if (searchText.isEmpty()) {
            mainTitle.setText("Please enter a word to search.");
            return;
        }

        boolean accepted = searchWord(currentNode, searchText);

        if (accepted) {
            mainTitle.setText("The word is accepted.");
            isSearchAccepted = true; // Imposta lo stato per indicare che la ricerca è stata accettata
        } else {
            mainTitle.setText("The word is rejected.");
        }
    }

    private boolean searchWord(GraphManager.Node currentNode, String searchText) {
        String remainingText = searchText;
        StringBuilder concatenatedValues = new StringBuilder();

        System.out.println("Starting search from node: " + currentNode.getName());
        System.out.println("Searching for text: " + searchText);

        while (remainingText.length() > 0) {
            // Trova la transizione per il nodo corrente
            GraphManager.Arrow transition = graph.findTransition(currentNode, remainingText);

            if (transition == null) {
                // Se non troviamo una transizione, controlliamo se abbiamo concatenato i valori sufficienti
                if (concatenatedValues.toString().equals(searchText)) {
                    return true; // La parola è accettata
                } else {
                    return false; // La parola è rifiutata
                }
            }

            // Aggiungi il valore dell'arco alla concatenazione
            concatenatedValues.append(transition.getValue());
            System.out.println("Transition found: " + transition.getValue());

            // Aggiorna il testo rimanente e il nodo corrente
            remainingText = remainingText.substring(transition.getValue().length());
            currentNode = transition.getEndNode();

            // Se il testo rimanente è vuoto e il nodo finale è uno stato finale, accetta la parola
            if (remainingText.isEmpty() && currentNode.isFinal()) {
                if (concatenatedValues.toString().equals(searchText)) {
                    return true; // La parola è accettata
                } else {
                    return false; // La parola è rifiutata
                }
            }
        }

        // Se siamo usciti dal ciclo e il testo rimanente non è vuoto
        return concatenatedValues.toString().equals(searchText);
    }

}
