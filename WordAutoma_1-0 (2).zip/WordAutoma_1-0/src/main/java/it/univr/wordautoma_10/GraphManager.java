package it.univr.wordautoma_10;

import java.util.ArrayList;
import java.util.List;

public class GraphManager {

    private List<Node> nodeList;
    private List<Arrow> arrowList;

    public GraphManager() {
        nodeList = new ArrayList<>();
        arrowList = new ArrayList<>();
    }

    public void setNode(String node) {
        if (!containsNode(node)) {
            nodeList.add(new Node(node));
        }
    }

    public void setArrow(String node1Name, String value, String node2Name) {
        Node node1 = getNode(node1Name);
        Node node2 = getNode(node2Name);

        if (node1 == null) {
            node1 = new Node(node1Name);
            nodeList.add(node1);
        }

        if (node2 == null) {
            node2 = new Node(node2Name);
            nodeList.add(node2);
        }

        arrowList.add(new Arrow(node1, value, node2));
    }

    public void setInit(String node) {
        Node n = getNode(node);
        if (n != null) {
            n.setInit(true);
        }
    }

    public void setFinal(String node) {
        Node n = getNode(node);
        if (n != null) {
            n.setFinal(true);
        }
    }

    public Node getNode(String nodeName) {
        for (Node node : nodeList) {
            if (node.isEqual(nodeName)) {
                return node;
            }
        }
        return null;
    }

    private boolean containsNode(String nodeName) {
        return getNode(nodeName) != null;
    }

    public boolean hasInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return true;
            }
        }
        return false;
    }

    public Node nodeInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return node;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("GraphManager:\n");
        sb.append("Nodes:\n");
        for (Node node : nodeList) {
            sb.append("  ").append(node).append("\n");
        }
        sb.append("Arrows:\n");
        for (Arrow arrow : arrowList) {
            sb.append("  ").append(arrow).append("\n");
        }
        return sb.toString();
    }

    public List<Node> hasNext(String node1){
        List<Node> nextNodes= new ArrayList<>();
        for (Arrow arrow: arrowList){
            if(node1.equals(arrow.node2)) //arrow.getNode1Name()
                nextNodes.add(arrow.node2);
        }
        return nextNodes;
    }

    public List<Arrow> nextArrow(String node1){
        List<Arrow> nextArrow= new ArrayList<>();
        for (Arrow arrow: arrowList){
            if(node1.equals(arrow.node2))   //arrow.getNode1Name()
                nextArrow.add(arrow);
        }
        return nextArrow;
    }

    boolean nodeHasValue(String node, String value) {   // usato in graph
        for (Arrow arrow : arrowList) {
            if (arrow.getNode1Name().equals(node) && arrow.getArrowValue().equals(value)) {
                return true;
            }
        }
        return false;
    }

    public static class Node {
        private String name;
        private boolean isInit;
        private boolean isFinal;

        public Node(String name) {
            this.name = name;
            this.isInit = false;
            this.isFinal = false;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isInit() {
            return isInit;
        }

        public void setInit(boolean isInit) {
            if (!isFinal) {
                this.isInit = isInit;
            }
        }

        public boolean isFinal() {
            return isFinal;
        }

        public void setFinal(boolean isFinal) {
            if (!isInit) {
                this.isFinal = isFinal;
            }
        }

        public boolean isEqual(String name) {
            return this.name.equals(name);
        }

        public String toString() {
            return "Node{name='" + name + "', isInit=" + isInit + ", isFinal=" + isFinal + "}";
        }
    }

    public static class Arrow {
        private final Node node1;
        private final String value;
        private final Node node2;

        public Arrow(Node node1, String value, Node node2) {
            this.node1 = node1;
            this.value = value;
            this.node2 = node2;
        }

        public String getNode1Name() {
            return node1.getName();
        }

        public String getNode2Name() {
            return node2.getName();
        }

        public String getArrowValue() {
            return value;
        }

        public String toString() {
            return "Arrow{from=" + node1.getName() + ", value='" + value + "', to=" + node2.getName() + "}";
        }
    }

    public void printNodes() {
        System.out.println("Nodes:");
        for (Node node : nodeList) {
            System.out.println("  " + node);
        }
    }

    public void printArrows() {
        System.out.println("Arrows:");
        for (Arrow arrow : arrowList) {
            System.out.println("  " + arrow);
        }
    }

    /*public Node pathSelection(String key){
        Node node = nodeInit();

        int maxPrefix, count, kl;
        while (key != null){
            List<Arrow> nextA= nextArrow(node.name);

            maxPrefix= 0;
            count= 0;
            kl=key.length();

            for(Arrow arrow: nextA){
                int l=arrow.value.length();
                for(int i=0; i<l; i++){
                    if(arrow.value.charAt(i) == key.charAt(kl - i)){
                        count++;
                    }else{
                        count=0;
                        break;
                    }
                }
                if(maxPrefix < count) {
                    maxPrefix = count;
                    node= arrow.node2;
                }
            }

            key.substring(maxPrefix);
        }

        if(node.isFinal)
            return node;

        return null;
    }*/

    // Metodo per verificare la validità dell'automa
    public boolean isValidAutoma(String key) {
        Node currentNode = nodeInit();
        if (currentNode == null) {
            System.out.println("No initial node found.");
            return false; // Nessun nodo iniziale
        }

        Node finalNode = pathSelection(key);
        if (finalNode == null) {
            System.out.println("No valid path found for the key: " + key);
            return false; // Nessun percorso valido trovato
        }

        if (!finalNode.isFinal()) {
            System.out.println("The final node is not an accepting state.");
            return false; // Il nodo finale non è uno stato di accettazione
        }

        if (!key.isEmpty()) {
            System.out.println("The entire key was not consumed: remaining key = " + key);
            return false; // La chiave non è stata consumata completamente
        }

        return true; // L'automa è valido e la chiave è accettata
    }

    private int getLongestPath(String arrowValue, String key) {
        int maxLength = Math.min(arrowValue.length(), key.length());
        int count = 0;

        while (count < maxLength && arrowValue.charAt(count) == key.charAt(count)) {
            count++;
        }

        return count;
    }

    public Node pathSelection(String key) {
        Node currentNode = nodeInit();  // Nodo iniziale
        if (currentNode == null) {
            System.out.println("Error: No initial state defined.");
            return null;  // Non esiste un nodo iniziale
        }

        while (!key.isEmpty()) {
            List<Arrow> nextArrows = nextArrow(currentNode.getName());
            Arrow bestMatch = null;
            int maxPrefixLength = 0;

            // Trova l'arco con il valore di prefisso più lungo
            for (Arrow arrow : nextArrows) {
                int prefixLength = getLongestPath(arrow.getArrowValue(), key);

                // Debug: Visualizza il confronto
                System.out.println("Checking arrow: " + arrow.getArrowValue() + " with prefix length: " + prefixLength);

                if (prefixLength > maxPrefixLength) {
                    maxPrefixLength = prefixLength;
                    bestMatch = arrow;
                }
            }

            if (bestMatch == null) {
                return null;  // Nessuna transizione corrispondente trovata
            }

            // Avanza al nodo successivo e aggiorna la chiave rimanente
            currentNode = bestMatch.node2;
            key = key.substring(maxPrefixLength);

            // Debug: Visualizza lo stato attuale
            System.out.println("Current node: " + currentNode.getName() + ", remaining key: " + key);

            // Se la chiave è vuota e il nodo è finale, accetta la parola
            if (key.isEmpty()) {
                if (currentNode.isFinal()) {
                    System.out.println("Word accepted at node: " + currentNode.getName());
                    return currentNode;
                } else {
                    System.out.println("Current node is not final: " + currentNode.getName());
                    return null;
                }
            }
        }

        // Verifica se il nodo finale è raggiunto con chiave vuota
        boolean isAccepted = currentNode.isFinal();
        System.out.println("Final node: " + currentNode.getName() + ", accepted: " + isAccepted);
        return isAccepted ? currentNode : null;
    }

}