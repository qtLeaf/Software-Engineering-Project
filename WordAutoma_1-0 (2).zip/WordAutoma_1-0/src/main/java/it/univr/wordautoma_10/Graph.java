package it.univr.wordautoma_10;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Graph {

    private final List<GraphManager.Arrow> arrowList;    // List to hold arrows (edges) between nodes
    private final List<GraphManager.Node> nodeList;

    private String dotContent;

    String dotFile;
    String imgFile;

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    public Graph(String fileName) {
        arrowList = new ArrayList<>();
        nodeList = new ArrayList<>();

        dotContent = "digraph " + " {\n" + "\tnode[fontname=\"Open Sans\", shape=\"circle\"]\n" + "\t\"\"[shape=\"none\"]";
        this.dotFile= PATH + fileName + ".dot";
        this.imgFile= PATH + fileName + ".png";
        close();
    }

    public void addNode(String nodeName) {
        if (findNode(nodeName) == null) {
            nodeList.add(new GraphManager.Node(nodeName));
            System.out.println("Added node: " + nodeName);
        }
    }

    /*
    // Aggiungo un arco tra due nodi inseriti (posso aggiungere qui in una lista con gli archi)
    public void addArrow(String node1, String value, String node2) {
        //rimovere ultima riga, //se esiste la non la aggiungo
        setDotContent("\t" + node1 + "->" + node2 + "[label=\"" + value + "\"]\n");
    }*/

    public void addArrow(String node1, String value, String node2) {
        GraphManager.Node startNode = findNode(node1);
        GraphManager.Node endNode = findNode(node2);
        if (startNode != null && endNode != null) {
            arrowList.add(new GraphManager.Arrow(startNode, value, endNode));
        }
        setDotContent("\t" + node1 + "->" + node2 + "[label=\"" + value + "\"]\n");
    }

    public void setNodeInit(String node){
        setDotContent("\t\"\" -> " + node + "\n");
    }

    // Aggiunge graficamente un cerchio ad un nodo per renderlo finale
    public void setNodeFinal(String node){
        setDotContent("\t" + node + "[shape=\"doublecircle\"]\n");
    }

    //aggiunge una stringa al dotContent
    private void setDotContent(String esistenceCheck){
        if(!dotContent.contains(esistenceCheck)){
            dotContent= dotContent.replace("}", "");
            dotContent+= esistenceCheck;
            close();
        }
    }

    // Rimuove un nodo scelto
    public void removeNode(String nodeToRemove) {
        // Remove the node line
        dotContent = dotContent.replaceAll("\\b" + nodeToRemove + "\\b.*?;\n", "\n");

        // Remove any edges involving the node being removed
        dotContent = dotContent.replaceAll("\\s*" + nodeToRemove + "\\s*--\\s*\\w+\\s*\\[.*?\\];?\n", "\n");
        dotContent = dotContent.replaceAll("\\s*\\w+\\s*--\\s*" + nodeToRemove + "\\s*\\[.*?\\];?\n", "\n");
    }

    // Chiude il file .dot e lo esegue per ottenere il .png (diverso per windows, serve il path di graphviz)
    public void close() {
        dotContent += "}\n";
        try {
            FileWriter writer = new FileWriter(dotFile);
            writer.write(dotContent);
            writer.close();

            String dotPath = "src/main/resources/it/univr/wordautoma_10/Graphviz_11/bin/dot.exe";

            ProcessBuilder pb = new ProcessBuilder(dotPath, "-Tpng", "-o" + imgFile, dotFile);

            Process process = pb.start();
            process.waitFor();
            System.out.println("Graph image generated: " + imgFile);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    /*
    public GraphManager.Arrow findTransition(GraphManager.Node node, String value) {
        for (GraphManager.Arrow arrow : arrowList) {
            if (arrow.getStartNode().equals(node) && arrow.getValue().equals(value)) {
                return arrow;
            }
        }
        return null;
    }*/

    public GraphManager.Node findNode(String nodeName) {
        String normalizedNodeName = nodeName.trim().toLowerCase();
        System.out.println("Searching for node: " + normalizedNodeName);
        System.out.println("Total nodes in list: " + nodeList.size());
        for (GraphManager.Node node : nodeList) {
            String normalizedNodeNameInList = node.getName().trim().toLowerCase();
            System.out.println("Checking node: " + normalizedNodeNameInList);
            if (normalizedNodeNameInList.equals(normalizedNodeName)) {
                System.out.println("Node found: " + normalizedNodeName);
                return node;
            }
        }
        System.out.println("Node not found: " + normalizedNodeName);
        return null;
    }

    public GraphManager.Arrow findTransition(GraphManager.Node node, String remainingText) {
        for (GraphManager.Arrow arrow : arrowList) {
            System.out.println("Checking arrow: " + arrow.getStartNode().getName() + " --" + arrow.getValue() + "--> " + arrow.getEndNode().getName());
            if (arrow.getStartNode().equals(node) && remainingText.startsWith(arrow.getValue())) {
                return arrow;
            }
        }
        return null; // No valid transition found
    }

    public GraphManager.Arrow[] getArrowList() {
        return arrowList.toArray(new GraphManager.Arrow[arrowList.size()]);
    }
}
