package it.univr.wordautoma_10;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalTime;

public class ControllerStart {

    @FXML
    public ComboBox<String> StateInit = new ComboBox<>();

    @FXML
    public ComboBox<String> StateFinal = new ComboBox<>();

    ObservableList<String> items = FXCollections.observableArrayList();

    private Graph graph;

    @FXML
    public TextArea outputTextArea;

    @FXML
    private TextField promptNode;

    @FXML
    public TextField promptValue;

    @FXML
    private TextField promptNode2;

    @FXML
    private ImageView prevImg;

    @FXML
    public Button submitAddlink;

    @FXML
    public Button submitButton;

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    private final String nomeFile= "graph";

    // Initialize method can be used to pass the stage reference
    public void initialize() {
        graph = new Graph(nomeFile);

        promptNode.setOnAction(event -> promptNode.setDisable(false));
        promptValue.setOnAction(event -> promptValue.setDisable(false));
        promptNode2.setOnAction(event -> promptNode2.setDisable(false));

        // Add listeners to text fields to validate the submitAddlink button
        promptNode.textProperty().addListener((observable, oldValue, newValue) -> validateAddLinkButton());
        promptValue.textProperty().addListener((observable, oldValue, newValue) -> validateAddLinkButton());
        promptNode2.textProperty().addListener((observable, oldValue, newValue) -> validateAddLinkButton());

        updateImage();

        presetAreaText();

        clearFile();
        viewNode();

        StateInit.valueProperty().addListener((observable, oldValue, newValue) -> {
            validateSubmitButton();
            graph.setNodeInit(StateInit.getValue());
            updateImage();
        });
        StateFinal.valueProperty().addListener((observable, oldValue, newValue) -> {
            validateSubmitButton();
            graph.setNodeFinal(StateFinal.getValue());
            updateImage();
        });

        submitButton.setDisable(true);
        submitAddlink.setDisable(true);  // Initially disable the add link button
    }

    @FXML
    public void onSubmit(javafx.event.ActionEvent event) throws IOException {
        // Inizializza il GraphManager basato sul grafo
        GraphManager graphManager = graph.getGraphManager(); // Assumendo che il metodo getGraphManager() esista in Graph

        // Carica la scena successiva
        FXMLLoader loader = new FXMLLoader(getClass().getResource("testScene.fxml"));
        Parent root = loader.load();

        // Ottieni il controller della scena successiva
        ControllerTest controllerTest = loader.getController();

        // Passa il GraphManager al controller della scena successiva
        controllerTest.setGraphManager(graphManager);

        // Passa il nodo iniziale, se necessario
        controllerTest.setInitialNode(StateInit.getValue()); // Assumendo che StateInit.getValue() restituisca il nodo iniziale

        // Imposta la nuova scena
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.getScene().setRoot(root);
    }

    /*
    public void onSubmitLink() {
        String selectedNode = promptNode.getText();
        String selectedValue = promptValue.getText();
        String selectedNode2 = promptNode2.getText();

        if (selectedNode != null && selectedNode2 != null) {
            System.out.println("Link submitted between nodes: " + selectedNode +
                    " and " + selectedNode2 + " value " + selectedValue);
            System.out.println("The event was done correctly.");
            promptNode.clear();
            promptValue.clear();
            promptNode2.clear();
            String newText = "You added: " + selectedNode + " ~ " + selectedValue + " ~ " + selectedNode2 + "\n";

            graph.addArrow(selectedNode, selectedValue, selectedNode2);
            updateImage();
            // Append the new text to the existing text
            outputTextArea.appendText(newText);

            // Call appendNodeToList to add the new nodes to the list
            appendNodeToList(selectedNode);
            appendNodeToList(selectedNode2);
            //viewNode();

        } else {
            System.out.println("Please select a node.");
        }
    }*/

    public void onSubmitLink() {
        String selectedNode = promptNode.getText();
        String selectedValue = promptValue.getText();
        String selectedNode2 = promptNode2.getText();

        if (selectedNode != null && selectedNode2 != null) {
            graph.addNode(selectedNode);  // Aggiungi il nodo se non esiste
            graph.addNode(selectedNode2); // Aggiungi l'altro nodo se non esiste
            graph.addArrow(selectedNode, selectedValue, selectedNode2);

            System.out.println("Link submitted between nodes: " + selectedNode + " and " + selectedNode2 + " value " + selectedValue);
            System.out.println("The event was done correctly.");
            promptNode.clear();
            promptValue.clear();
            promptNode2.clear();
            String newText = "You added: " + selectedNode + " ~ " + selectedValue + " ~ " + selectedNode2 + "\n";
            outputTextArea.appendText(newText);
            updateImage();
            appendNodeToList(selectedNode);
            appendNodeToList(selectedNode2);
        } else {
            System.out.println("Please select a node.");
        }
    }

    private void validateSubmitButton() {
        submitButton.setDisable(StateInit.getValue() == null || StateFinal.getValue() == null);
    }

    private void validateAddLinkButton() {
        submitAddlink.setDisable(promptNode.getText().isEmpty() ||
                promptValue.getText().isEmpty() ||
                promptNode2.getText().isEmpty());
    }

    @FXML
    public void viewNode() {
        StateInit.setItems(items);
        StateFinal.setItems(items);

        try (BufferedReader reader = new BufferedReader(new FileReader(PATH + "nodesName.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                items.add(line);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void appendNodeToList(String nodeName) {
        if (!nodeExist(PATH + "nodesName.txt", nodeName)) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(PATH + "nodesName.txt", true))) {
                writer.write(nodeName + System.lineSeparator());
                items.add(nodeName); // Add to the list only if it's not already present
            } catch (IOException e) {
                System.out.println("An error occurred while writing to the file.");
            }
        }
    }

    public boolean nodeExist(String filePath, String nodeToFind) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals(nodeToFind)) {
                    return true;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    private void clearFile(){
        try {
            // Open the file in write mode, which clears its content
            FileWriter fileWriter = new FileWriter(PATH + "nodesName.txt");

            // Close the file writer
            fileWriter.close();

            System.out.println("File cleared successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while clearing the file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void updateImage() {
        LocalTime time = LocalTime.now();
        System.out.println("Current Time: " + time);
        Image newImage = new Image("file:" + PATH + nomeFile + ".png");
        prevImg.setImage(newImage);
    }

    private void presetAreaText(){
        /*double prefWidth = 1.0;
        double prefHeight = 1.0;
        outputTextArea.setPrefSize(prefWidth, prefHeight);*/
        outputTextArea.setEditable(false);
        outputTextArea.setMouseTransparent(true);
        outputTextArea.setFocusTraversable(false);
    }
}
