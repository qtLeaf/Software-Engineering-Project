package it.univr.wordautoma;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Graph {

    public String dotContent;

    String dotFile;
    String imgFile;

    public Graph(String fileName) {

        String PATH = "src/main/resources/it/univr/wordautoma/automas/";
        this.dotFile = PATH + fileName + ".dot";
        this.imgFile = PATH + fileName + ".png";

        if(!graphExist(PATH + "filesName.txt", fileName)) {
            try (PrintWriter wr = new PrintWriter(PATH + "filesName.txt")) {
                wr.println(fileName);
                dotContent = "graph " + fileName + " {\n" +
                        "\tnode[fontname=\"Open Sans\", shape=\"circle\"]\n";
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            // Attempt to read existing graph content from file
            try {
                dotContent = new String(Files.readAllBytes(Paths.get(dotFile)));
                // If file is empty, reinitialize the content
                if (dotContent.isEmpty()) {
                    dotContent = "graph " + fileName + " {\n" +
                            "\tnode[fontname=\"Open Sans\", shape=\"circle\"];\n";
                    dotContent += "}\n"; // Close the graph definition
                }
            } catch (IOException e) {
                // If reading fails, initialize with default content
                dotContent = "graph " + fileName + " {\n" +
                        "\tnode[fontname=\"Open Sans\", shape=\"circle\"];\n";
                dotContent += "}\n";
            }
        }
    }

    public void close() {
        dotContent += "}\n";
        try {
            // Write to the DOT file
            FileWriter writer = new FileWriter(dotFile);
            writer.write(dotContent);
            writer.close();

            // Correct path to the dot executable (remove the semicolon)
            String dotPath = "src/main/resources/it/univr/wordautoma/Graphviz_11/bin/dot.exe";

            // Setup ProcessBuilder
            ProcessBuilder pb = new ProcessBuilder(dotPath, "-Tpng", dotFile, "-o", imgFile);
            pb.redirectErrorStream(true);  // Redirect errors and output to standard output

            // Start the process
            Process process = pb.start();

            // Debug output from the process
            try (InputStream is = process.getInputStream();
                 InputStreamReader isr = new InputStreamReader(is);
                 BufferedReader br = new BufferedReader(isr)) {
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);  // Print all output from the process
                }
            }

            // Wait for the process to complete
            int exitValue = process.waitFor();
            if (exitValue == 0) {
                System.out.println("Graph image generated: " + imgFile);
            } else {
                System.out.println("Graphviz exited with error code: " + exitValue);
            }
        } catch (IOException | InterruptedException e) {
            //e.printStackTrace();
            System.out.println("I/O error or interrupted while generating graph");
        }
    }

    public void addArrow(String node1, String value, String node2) {
        //rimovere ultima riga
        String esistenceCheck = "\t" + node1 + "--" + node2 + "[label=\"" + value + "\"]\n";
        if (!dotContent.contains(esistenceCheck)) {
            dotContent = dotContent.replace("}\n", "");
            dotContent += esistenceCheck;
            close();
        }
    }

    public String toString() {
        return dotContent;
    }

    public boolean graphExist(String filePath, String fileToFind){
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals(fileToFind)) {
                    return true;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return false;
    }
}