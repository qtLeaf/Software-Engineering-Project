package it.univr.wordautoma_10;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import java.time.LocalTime;

// Controller for Scene 2
public class ControllerTest {

    @FXML
    public Text mainTitle;

    @FXML
    private TextField searchTextField;

    @FXML
    private ImageView prevImg;

    private Graph graph;  // Assumendo che graphManager sia inizializzato in qualche altro modo

    private String initialNode;  // Nodo iniziale passato come nome

    private final String nomeFile= "graph";

    private final String PATH= "src/main/resources/it/univr/wordautoma_10/automas/";

    public void initialize() {
        try {
            uploadImage();
        } catch (Exception e) {
            mainTitle.setText("Error loading image: " + e.getMessage());
        }
    }

    public void uploadImage() {
        try {
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);
            Image newImage = new Image("file:" + PATH + nomeFile + ".png");
            prevImg.setImage(newImage);
        } catch (Exception e) {
            mainTitle.setText("Failed to load graph image.");
            e.printStackTrace();
        }
    }

    public void setGraphManager(Graph graph) {
        this.graph = graph;
    }

    public void setInitialNode(String initialNode) {
        this.initialNode = initialNode;
    }

    @FXML
    public void goSearch() {
        if (initialNode == null || initialNode.trim().isEmpty()) {
            mainTitle.setText("Initial node is not set.");
            return;
        }

        GraphManager.Node currentNode = graph.findNode(initialNode);
        if (currentNode == null) {
            mainTitle.setText("Initial node not found.");
            return;
        }

        String searchText = searchTextField.getText().trim();
        if (searchText.isEmpty()) {
            mainTitle.setText("Please enter a word to search.");
            return;
        }

        boolean accepted = searchWord(currentNode, searchText);

        if (accepted) {
            mainTitle.setText("The word is accepted.");
        } else {
            mainTitle.setText("The word is rejected.");
        }
    }

    private boolean searchWord(GraphManager.Node currentNode, String searchText) {
        String remainingText = searchText;

        System.out.println("Starting search from node: " + currentNode.getName());
        System.out.println("Searching for text: " + searchText);

        while (remainingText.length() > 0) {
            System.out.println("Current Node: " + currentNode.getName());
            System.out.println("Remaining Text: " + remainingText);

            GraphManager.Arrow transition = graph.findTransition(currentNode, remainingText);

            if (transition == null) {
                System.out.println("No transition found for: " + remainingText);
                return false; // No transition found, word is rejected
            }

            System.out.println("Transition found: " + transition.getValue());
            remainingText = remainingText.substring(transition.getValue().length());
            currentNode = transition.getEndNode();

            if (remainingText.isEmpty() && currentNode.isFinal()) {
                System.out.println("Word accepted.");
                return true; // Word is accepted
            }
        }
        System.out.println("Word rejected.");
        return false; // Word is rejected
    }

}
