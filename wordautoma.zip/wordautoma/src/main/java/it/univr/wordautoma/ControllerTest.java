package it.univr.wordautoma;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

import java.time.LocalTime;
import java.util.List;

// Controller for Scene 2
public class ControllerTest {

    @FXML
    public Text mainTitle;

    @FXML
    private TextField searchTextField;

    @FXML
    private Text pathDisplay; // Aggiungiamo questo campo per collegarlo alla GUI

    @FXML
    private Text valueDisplay; // Aggiungiamo questo campo per visualizzare i valori



    @FXML
    private ImageView prevImg;

    public Graph graph;  // Assumendo che graphManager sia inizializzato in qualche altro modo

    public GraphManager graphManager;
    public String initialNode;  // Nodo iniziale passato come nome

    private final String nomeFile= "graph";

    private final String PATH= "src/main/resources/it/univr/wordautoma/automas/";

    public void initialize() {
        try {
            uploadImage();
        } catch (Exception e) {
            mainTitle.setText("Error loading image: " + e.getMessage());
        }
    }

    //Servono per passare di scena il grafo
    public void setGraph(Graph graph) {
        this.graph = graph;
    }
    public void setGraphManager(GraphManager graphManager) {
        this.graphManager= graphManager;
    }
    @FXML
    public void goSearch() {
        String searchText = searchTextField.getText().trim();
        if (searchText.isEmpty()) {
            mainTitle.setText("Please enter a word to search.");
            return;
        }


        // Stampa i nodi e gli archi
        //graphManager.printNodes();
        //graphManager.printArrows();

        // Esegui la ricerca della parola
        StringBuilder[] result = test(searchText);

        uploadNewImage();
        valueDisplay.setText(result[0].toString());
        pathDisplay.setText(result[1].toString());

    }

    public StringBuilder[] test(String key) {
        graphManager.printNodes();
        graphManager.printArrows();
        graphManager.printArrowsNodes();

        StringBuilder path[] = new StringBuilder[2];  // path[0] -> arrow path, path[1] -> node path
        path[0] = new StringBuilder();// nodes
        path[1] = new StringBuilder();// arrow values

        GraphManager.Node currentNode = graphManager.nodeInit();  // Get the initial node

        graph.preTest(currentNode.getName());

        GraphManager.Arrow arrowMax = null;
        int maxValue = 0;

        System.out.println(currentNode.getName());
        path[0].append(currentNode.getName());  // Add initial node to node path

        System.out.println("Starting pathSelection with key: " + key);

        while (!key.isEmpty()) {
            List<GraphManager.Arrow> nextArrows = graphManager.nextArrow(currentNode.getName());


            // Find an arrow whose value matches the start of the key
            for (GraphManager.Arrow arrow : nextArrows) {
                System.out.println(arrow);
                if (key.startsWith(arrow.getArrowValue())) {
                    if (arrow.getArrowValue().length() > maxValue){
                        arrowMax = arrow;
                        maxValue = arrow.getArrowValue().length();
                    }
                }
            }

            if (arrowMax == null) {
                System.out.println("No matching arrow found. Exiting...");
                path[1].append(" X");
                graph.closeTest();
                return path;
            }

            graph.highlightedArrow(arrowMax.getNode1Name(), arrowMax.getArrowValue(), arrowMax.getNode2Name());

            // Add the selected arrow to the arrow path
            path[1].append(" ").append(arrowMax.getArrowValue());

            // Add the next node to the node path
            path[0].append(" ").append(arrowMax.getNode2Name());

            // Move to the next node and update the remaining key
            currentNode = arrowMax.getNode2();
            key = key.substring(arrowMax.getArrowValue().length());
            maxValue = 0;  // Reset maxValue for the next iteration and arrowMax
            arrowMax=null;
        }

        graph.closeTest();
        // Check if the final node is reached with an empty key and if it is a final state
        if (currentNode.isFinal()) {
            System.out.println("Word accepted at final node: " + currentNode.getName());
            path[0].append(" ✔");  // Add acceptance marker to the node path
            return path;
        } else {
            System.out.println("Final node is NOT an accepting state.");
            path[0].append(" X");  // Add rejection marker to the node path
            return path;
        }
    }

    public void uploadImage() {
        try {
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);
            Image newImage = new Image("file:" + PATH + nomeFile + ".png");
            prevImg.setImage(newImage);
        } catch (Exception e) {
            mainTitle.setText("Failed to load graph image.");
            e.printStackTrace();
        }
    }

    public void uploadNewImage() {
        try {
            LocalTime time = LocalTime.now();
            System.out.println("Current Time: " + time);
            Image newImage = new Image("file:" + PATH + "test" + nomeFile + ".png");
            prevImg.setImage(newImage);
        } catch (Exception e) {
            mainTitle.setText("Failed to load graph image.");
            e.printStackTrace();
        }
    }
}

