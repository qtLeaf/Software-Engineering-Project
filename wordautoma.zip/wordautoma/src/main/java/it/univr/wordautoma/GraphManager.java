package it.univr.wordautoma;

import java.util.ArrayList;
import java.util.List

public class GraphManager {

    private List<Node> nodeList;
    private List<Arrow> arrowList;

    public GraphManager() {
        nodeList = new ArrayList<>();
        arrowList = new ArrayList<>();
    }

    public Node setNode(String nodeName) {
        Node existingNode = getNode(nodeName);
        if (existingNode == null) {
            existingNode = new Node(nodeName);
            nodeList.add(existingNode);
        }
        return existingNode;
    }

    public void setArrow(String node1Name, String value, String node2Name) {
        Node node1 = setNode(node1Name);
        Node node2 = setNode(node2Name);
        arrowList.add(new Arrow(node1, value, node2));
    }

    public void setInit(String nodeName) {
        Node node = getNode(nodeName);
        if (node != null) {
            node.setInit(true);
        }
    }

    public void setFinal(String nodeName) {
        Node node = getNode(nodeName);
        if (node != null) {
            node.setFinal(true);
        }
    }

    Node getNode(String nodeName) {
        for (Node node : nodeList) {
            if (node.isEqual(nodeName)) {
                return node;
            }
        }
        return null;
    }

    public String hasInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return node.getName();
            }
        }
        return null;
    }

    public Node nodeInit() {
        for (Node node : nodeList) {
            if (node.isInit()) {
                return node;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("GraphManager:\n");
        sb.append("Nodes:\n");
        for (Node node : nodeList) {
            sb.append("  ").append(node).append("\n");
        }
        sb.append("Arrows:\n");
        for (Arrow arrow : arrowList) {
            sb.append("  ").append(arrow).append("\n");
        }
        return sb.toString();
    }


    public List<Arrow> nextArrow(String node1) {
        List<Arrow> nextArrows = new ArrayList<>();
        for (Arrow arrow : arrowList) {
            if (node1.equals(arrow.getNode1Name())) {
                nextArrows.add(arrow);
            }
        }
        return nextArrows;
    }
    public Node getNextNode(Node node1, String value) {
        List<Arrow> nextArrows = new ArrayList<>();
        for (Arrow arrow : arrowList ) {
            if (node1.equals(arrow.getNode1Name()) && value.equals(arrow.getArrowValue())) {
                nextArrows.add(arrow);
                return arrow.node2;
            }
        }
        return null;
    }

    public boolean nodeHasValue(String node, String value) {
        for (Arrow arrow : arrowList) {
            if (arrow.getNode1Name().equals(node) && arrow.getArrowValue().equals(value)) {
                return true;
            }
        }
        return false;
    }

    public static class Node {
        private String name;
        private boolean isInit;
        private boolean isFinal;

        public Node(String name) {
            this.name = name;
            this.isInit = false;
            this.isFinal = false;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isInit() {
            return isInit;
        }

        public void setInit(boolean isInit) {
            if (!isFinal) {
                this.isInit = isInit;
            }
        }

        public boolean isFinal() {
            return isFinal;
        }

        public void setFinal(boolean isFinal) {
            if (!isInit) {
                this.isFinal = isFinal;
            }
        }

        public boolean isEqual(String name) {
            return this.name.equals(name);
        }

        @Override
        public String toString() {
            return "Node{name='" + name + "', isInit=" + isInit + ", isFinal=" + isFinal + "}";
        }
    }

    public class Arrow {
        private Node node1;
        private String value;
        private Node node2;

        public Arrow(Node node1, String value, Node node2) {
            this.node1 = node1;
            this.value = value;
            this.node2 = node2;
        }

        @Override
        public String toString() {
            return "Arrow{node1=" + node1.getName() + ", value='" + value + "', node2=" + node2.getName() + "}";
        }

        public String toStringPath() {
            return "[" + node1.getName() + "] - " + value + " > [" + node2.getName() + "]";
        }

        public String getNode1Name() {
            return node1.getName();
        }

        public String getNode2Name() {
            return node2.getName();
        }

        public String getArrowValue() {
            return value;
        }

        public Node getNode1() {
            return node1;
        }

        public Node getNode2() {
            return node2;
        }
    }

    public void printNodes() {
        System.out.println("Nodes:");
        for (Node node : nodeList) {
            System.out.println("  " + node);
        }
    }

    public void printArrows() {
        System.out.println("Arrows:");
        for (Arrow arrow : arrowList) {
            System.out.println("  " + arrow);
        }
    }

    public void printArrowsNodes() {
        System.out.println("Arrows Node:");
        for (Arrow arrow : arrowList) {
            System.out.println("  " + arrow.getNode1() + " " + arrow.getNode2() + "\n");
        }
    }
}
