package it.univr.wordautoma;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Graph {

    //private int nodes;
    //private final List<GraphManager.Node> nodeList;

    private String dotContent;

    private String testContent;

    String dotFile;
    String imgFile;

    String dotTestFile;
    String imgTestFile;

    private final String PATH= "src/main/resources/it/univr/wordautoma/automas/";

    public Graph(String fileName) {
        //nodeList = new ArrayList<>();

        dotContent = "digraph " + " {\n" + "\tnode[fontname=\"Open Sans\", shape=\"circle\"]\n" + "\t\"\"[shape=\"none\"] \n  bgcolor=\"transparent\";";
        this.dotFile= PATH + fileName + ".dot";
        this.imgFile= PATH + fileName + ".png";

        this.dotTestFile= PATH + "test" + fileName + ".dot";
        this.imgTestFile= PATH + "test" +  fileName + ".png";
        close();
    }

    // Aggiungo un arco tra due nodi inseriti (posso aggiungere qui in una lista con gli archi)
    public void addArrow(String node1, String value, String node2) {
        //rimovere ultima riga
            setDotContent("\t" + node1 + "->" + node2 + "[label=\"" + value + "\"]\n");
    }//se esiste la non la aggiungo

    public void setNodeInit(String node){
            setDotContent("\t\"\"->" + node + "\n");
    }

    // Aggiunge graficamente un cerchio ad un nodo per renderlo finale
    public void setNodeFinal(String node){
            setDotContent("\t" + node + "[shape=\"doublecircle\"]\n");

    }

    //aggiunge una stringa al dotContent
    private void setDotContent(String esistenceCheck){
        if(!dotContent.contains(esistenceCheck)){
            dotContent= dotContent.replace("}", "");
            dotContent+= esistenceCheck;
            close();
        }
    }

    // Rimuove un nodo scelto
    public void removeNode(String nodeToRemove) {
        // Remove the node line
        dotContent = dotContent.replaceAll("\\b" + nodeToRemove + "\\b.*?;\n", "\n");

        // Remove any edges involving the node being removed
        dotContent = dotContent.replaceAll("\\s*" + nodeToRemove + "\\s*--\\s*\\w+\\s*\\[.*?\\];?\n", "\n");
        dotContent = dotContent.replaceAll("\\s*\\w+\\s*--\\s*" + nodeToRemove + "\\s*\\[.*?\\];?\n", "\n");
    }

    // Chiude il file .dot e lo esegue per ottenere il .png (diverso per windows, serve il path di graphviz)
    public void close() {
        dotContent += "}\n";
        try {
            FileWriter writer = new FileWriter(dotFile);
            writer.write(dotContent);
            writer.close();

            ProcessBuilder pb = new ProcessBuilder("dot", "-Tpng", "-o" + imgFile, dotFile);
            Process process = pb.start();
            process.waitFor();
            System.out.println("Graph image generated: " + imgFile);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void preTest(String node){
        testContent= dotContent;
        highlightedFirstArrow(node);

    }

    public void highlightedFirstArrow(String node){
        testContent= testContent.replace("}", "");
        testContent= testContent.replace( "\"\"->" + node, "\"\"->" + node + "[color=\"red\"]");
        closeTest();
    }
    public void highlightedArrow(String node1, String value, String node2){
        testContent= testContent.replace("}", "");
        testContent= testContent.replace(node1 +"->" + node2 + "[label=\"" + value +"\"]", node1 +"->" + node2 + "[label=\"" + value +"\", color=\"red\"]");
        closeTest();
    }

    public void closeTest() {
        testContent += "}\n";
        try {
            FileWriter writer = new FileWriter(dotTestFile);
            writer.write(testContent);
            writer.close();

            ProcessBuilder pb = new ProcessBuilder("dot", "-Tpng", "-o" + imgTestFile, dotTestFile);
            Process process = pb.start();
            process.waitFor();
            System.out.println("Graph image generated: " + imgTestFile);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }



}