package it.univr.wordautoma;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class WordAutomaTest {

    private GraphManager graphManager;

    @BeforeEach
    void setUp() {
        graphManager = new GraphManager();
        // Imposta il grafo con nodi e archi per i test
        graphManager.setArrow("d", "5", "f");
        graphManager.setArrow("f", "8", "g");

        // Imposta il nodo finale
        graphManager.getNode("g").setFinal(true);  // Imposta "g" come nodo finale
    }

    @Test
    void testGetNextNode() {
        GraphManager.Node initialNode = graphManager.getNode("d");
        GraphManager.Node nextNode = graphManager.getNextNode(initialNode, "5");

        Assertions.assertNotNull(nextNode, "Il nodo successivo non dovrebbe essere null");
        Assertions.assertEquals("f", nextNode.getName(), "Il nodo successivo dovrebbe essere 'f'");
    }

    @Test
    void testWordAccepted() {
        // Simula la ricerca della parola "58"
        GraphManager.Node currentNode = graphManager.getNode("d");
        currentNode = graphManager.getNextNode(currentNode, "5");
        currentNode = graphManager.getNextNode(currentNode, "8");

        // Controlla che il nodo finale sia stato raggiunto
        Assertions.assertNotNull(currentNode, "Il nodo finale non dovrebbe essere null");
        Assertions.assertEquals("g", currentNode.getName(), "Il nodo finale dovrebbe essere 'g'");
        Assertions.assertTrue(currentNode.isFinal(), "Il nodo finale dovrebbe essere marcato come tale");
    }
}